# ECG Inception-ResNeXt accelerator - project status

## Verified (tests run in this environment)
| Stage | What | Result |
|---|---|---|
| 1 | CWT front end (cosine Morlet, 60x60 map, fused == direct) | `sim/t_stage1.m` 6/6 pass |
| 2 | Inception-ResNeXt network, forward + hand-written backward | `sim/t_stage2.m` 4/4 pass; gradient check 7e-8 |
| 3 | 4-bit weights (Eq.3 power-of-two scales), 8-bit activations, integer model, STE training | `sim/t_stage3.m` 4/5 pass; **QAT memorisation test FAILS** (documented limitation) |
| 4 | Integer engine in Verilog (`rtl/qnn/qnn_engine.v`) | **bit-exact with MATLAB on 8/8 golden vectors** (`sim/tb_qnn.v`) |
| 5 | Basys 3 wrapper (`rtl/basys3/basys3_qnn_top.v`) | board-path simulation PASS (beat 0 -> class F, LED[3]) |

## NOT verified
- **Accuracy.** The exported network is the post-training-quantised initialisation. All 8 golden vectors classify as F. No DS1/DS2 training has been run (PhysioNet not reachable from the build environment; only records 100 and 119 are local, and 119 has no annotations).
- **QAT.** The network cannot memorise 10 random inputs under 4W/8A quantisation: quantisation error is ~2.9x the logit spread between inputs (`sim/t_stage3_fidelity.m`). The paper's 99.5% depends on details not stated in the text (e.g. batch-norm, initialisation).
- **Synthesis.** Yosys (generic 7-series flow) runs out of memory on the engine. Partial fixes applied: single read port per memory, single write port, registered reads, divider removed. The remaining cause is not yet isolated (suspect the 64 KB activation RAM). **No LUT/BRAM/DSP numbers exist yet.**
- **Board.** Not programmed on a Basys 3. The XDC pin locations are from memory and must be checked against Digilent's master XDC.
- **CWT is not in hardware.** The engine takes the 60x60 map as input (computed by MATLAB Stage 1).
- **Interpretation choices** (see Stage 1/2 headers): omega = pi/2, scales 1-60, max pooling, ReLU after residual add, FC 16->5 head.

## Run
    octave-cli sim/t_stage1.m
    octave-cli sim/t_stage2.m
    octave-cli sim/t_stage3.m
    octave-cli --eval "source('sim/t_stage4_export.m')"   # regenerates rtl/qnn/gen and vec
    cd rtl/qnn && iverilog -g2012 -o ../../sim/qnn.vvp qnn_engine.v ../../sim/tb_qnn.v && vvp ../../sim/qnn.vvp
    cd rtl/basys3 && iverilog -g2012 -o ../../sim/board.vvp -I../qnn ../qnn/qnn_engine.v basys3_qnn_top.v ../../sim/tb_board.v && vvp ../../sim/board.vvp
